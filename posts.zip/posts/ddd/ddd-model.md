---
title: 도메인 모델 기초 (DDD)
date: 2021-06-03T19:00:00+09:00
tags:
- DDD
---

## 도메인

소프트웨어로 해결하고자 하는 문제 영역을 도메인 (domain) 이라고 하며, 하나의 도메인은 다시 하위 도메인으로 나눌 수 있다. 예를 들어 온라인 서점을 구현하고자 한다면 온라인 서점은 하나의 도메인이 될 수 있으며, 온라인 서점을 구현하는 데 필요한 상품 조회, 구매, 결제, 배송 등은 온라인 서점의 하위 도메인이 될 수 있다.

## 도메인 모델 패턴

도메인 모델은 일반적으로 네 개의 계층으로 구성된다.

| 계층           | 설명                                                         |
| -------------- | ------------------------------------------------------------ |
| Presentation   | 사용자의 요청을 처리하고 사용자에게 정보를 보여준다.         |
| Application    | 사용자가 요청한 기능을 실행한다. 업무 로직을 직접 구현하지 않으며, 도메인 계층을 조합해서 기능을 실행한다. |
| Domain         | 시스템이 제공할 기능을 구현한다.                             |
| Infrastructure | 데이터베이스나 메시징 시스템과 같은 외부 시스템과의 연동을 처리한다. |

## 도메인 영역의 주요 구성요소

위에서 살펴본 도메인 모델 패턴 중 도메인 영역은 도메인의 주요 개념을 표현하며 핵심이 되는 로직을 구현한다. 도메인 영역의 주요 구성 요소는 다음과 같다.

|요소|설명|
|---|---|
|엔티티 (Entity)|고유의 식별자를 갖는 객체로 자신의 라이프사이클을 갖는다. 도메인 모델의 데이터를 포함하며, 해당 데이터와 관련된 기능을 제공한다.|
|밸류 (Value)|고유의 식별자를 갖지 않으며, 주로 개념적으로 같은 데이터의 속성을 표현하기위해 사용한다.|
|애그리거트 (Aggregate)|서로 관련이 있는 엔티티와 밸류 객체를 개념적으로 하나로 묶은 것이다.|
|리포지터리 (Repository)|도메인 모델의 영속성을 처리한다. 예를 들어 DBMS 테이블에서 엔티티 객체를 로딩하거나 저장하는 기능을 제공한다.|
|도메인 서비스 (Domain Service)|특정 엔티티에 속하지 않은 도메인 로직을 제공한다. 예를 들어 '할인 금액 계산'을 위해서는 상품, 쿠폰, 회원 등급 등 다양한 조건이 필요한데, 이렇게 여러 엔티티와 밸류를 필요로 할 경우 도메인 서비스에서 로직을 구현한다.|


> [!note]
> NOTE
> 
> *엔티티* 에는 Order(주문) 객체가 있을 수 있으며, 주문 객체에는 주문 완료, 주문 취소 등의 기능을 제공할 수 있다. *밸류* 에는 Receiver(받는 사람) 객체가 있을 수 있으며, 받는 사람 객체에는 받는 사람의 이름, 전화번호 등이 있을 수 있다. 주문과 관련된 객체로는 주문 엔티티, 주문 항목 밸류, 주문자 밸류 등이 있을 수 있으며 이를 주문 *애그리거트* 로 묶을 수 있다.

## 요청 처리 흐름

[![](https://mermaid.ink/img/pako:eNptkc9Kw0AQxl9l2HP7AjkU1ArelLbHvcRkqtFmN242SikFhVysigrFP6UpCK2loBBqDxV8ou7mHUyltcV4G2Z-883MNw1icRuJQXw8CZBZWHTMA2G6lG0KfuajgHyhAFucScFrNRQG7FQqe1Ca076kbFXJgLrT1uN3UDexjiZJGKvBF-joXndGoMOu-gx1q68f70ANe7PxNaiP8-T5KaO44XlQRnHqWGjAbBqr1gD0VT95uKRsrfbDltDjviO5qBtQdZhN2SoD-Yyaug3VqK2jKcziSI8noF7fknCS1S1y13QY7O4foSXX-9RLVw8v_t_nrx1L8fX75szC519jfY8zH0mOuCjSsXb6mwZlAJTIQ3SREiMNbVMcU0JZM-UCzzYlbtvzM4lRNWs-5ogZSF6uM4sYUgS4hBbPXVDNb1Zs1ec)](https://mermaid.live/edit#pako:eNptkc9Kw0AQxl9l2HP7AjkU1ArelLbHvcRkqtFmN242SikFhVysigrFP6UpCK2loBBqDxV8ou7mHUyltcV4G2Z-883MNw1icRuJQXw8CZBZWHTMA2G6lG0KfuajgHyhAFucScFrNRQG7FQqe1Ca076kbFXJgLrT1uN3UDexjiZJGKvBF-joXndGoMOu-gx1q68f70ANe7PxNaiP8-T5KaO44XlQRnHqWGjAbBqr1gD0VT95uKRsrfbDltDjviO5qBtQdZhN2SoD-Yyaug3VqK2jKcziSI8noF7fknCS1S1y13QY7O4foSXX-9RLVw8v_t_nrx1L8fX75szC519jfY8zH0mOuCjSsXb6mwZlAJTIQ3SREiMNbVMcU0JZM-UCzzYlbtvzM4lRNWs-5ogZSF6uM4sYUgS4hBbPXVDNb1Zs1ec)
