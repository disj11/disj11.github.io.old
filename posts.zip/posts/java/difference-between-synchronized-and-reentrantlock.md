---
title: "synchronized 와 ReentrantLock 의 차이"
date: 2022-07-08T11:05:13+09:00
tags:
- java
---

## 개요

`synchronized` 와 `ReentrantLock`  모두 자바에서 [mutax](https://www.baeldung.com/cs/what-is-mutex) 를 구현하는 방법이다. 이 포스트에서는 `synchronized` 와 `ReentrantLock` 의 차이점을 알아본다.

## synchronized 와 ReentrantLock 의 차이

java 1.5 에서 추가된 `ReentrantLock`  은 `synchronized` 키워드에 비해 여러가지 편리한 기능을 제공한다. 어떠한 차이가 있는지 대표적인 차이점를 살펴보자.

첫번째 차이점은,  `synchronized` 는 unfair 하다는 것이다. unfair 하다는 것은 Lock을 획득하는 스레드가 반드시 대기시간이 가장 긴 스레드가 아닐 수도 있다는 것을 의미한다. 이로 인해 오랜 시간동안 임계 영역 (Critical Section) 에 들어가지 못하고, 대기하는 스레드가 생길 수도 있다. 반면에 `ReentrantLock` 은 기본적으로 unfair 하게 동작하지만 `ReentrantLock(boolean fair)` 생성자를 사용하여 fair/unfair 여부를 선택할 수 있다.

두번째 차이점으로, `synchronized` 는 Lock 획득 대기시간을 통제할 수 없다는 것이다. 이러한 이유로 Lock 획득을 위해 무기한 대기하는 스레드가 생길 수 있다. 반면에 `ReentrantLock` 은 `tryLock(long timeout, TimeUnit unit)` 메서드를 통해 대기시간을 설정할 수 있다. 만약 지정한 시간이 지나도 Lock 을 획득하지 못한다면 `false` 를 리턴한다.

`tryLock()` 메서드는 Lock을 점유하고 있는 스레드가 존재하지 않는 경우에는 즉시 Lock 획득 후 `true` 를 리턴하고, 그렇지 않은 경우에는  `false` 를 리턴하기 때문에, 이미 잠금을 획득한 스레드가 있는 경우 스레드를 차단하지 않고 다른 동작을 실행하고 싶은 경우에도 유용하게 사용할 수 있다.

이외에도 `ReentrantLock` 은 Lock 을 획득하기 위해 대기중인 스레드 수의 추정치를 리턴해주는 `getQueueLength()` 등 유용한 메서드를 제공한다. `ReentrantLock` 의 더 자세한 사용 방법이 궁금하다면 [Class ReentrantLock](https://docs.oracle.com/javase/7/docs/api/java/util/concurrent/locks/ReentrantLock.html) 문서를 참고한다.

## ReentrantLock 사용시 주의점

`synchronized` 키워드와 달리 `ReentrantLock` 은 개발자가 직접 Lock 을 설정하고 해제해야 한다. Lock 을 설정한 후에는 반드시 해제해야 하기 때문에 보통 `try`  문과 함께 사용된다.

```java
try {
    reentrantLock.lock();
} finally {
    reentrantLock.unlock();
}
```



